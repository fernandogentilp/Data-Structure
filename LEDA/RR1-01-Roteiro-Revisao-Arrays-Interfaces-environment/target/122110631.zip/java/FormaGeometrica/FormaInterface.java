package FormaGeometrica;

public interface FormaInterface {
    public double calculo();
}
